ace.define('ace/snippets/jade', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "jade";

});
