ace.define('ace/snippets/luapage', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "luapage";

});
