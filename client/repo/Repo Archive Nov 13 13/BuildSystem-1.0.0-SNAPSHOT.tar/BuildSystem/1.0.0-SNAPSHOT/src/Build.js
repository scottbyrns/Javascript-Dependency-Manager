com.scottbyrns.BuildSystem.Build(
	setup: function () {},
	constructor: function (id, name, pom, target) {
		this.id = id;
		this.name = name;
		this.pom = pom;
		this.target = target;
	},
	prototype: {
		
	}
);