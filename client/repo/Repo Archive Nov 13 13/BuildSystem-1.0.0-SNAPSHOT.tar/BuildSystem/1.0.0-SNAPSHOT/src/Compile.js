com.scottbyrns.BuildSystem.Compile({
	
	setup: function () {
		// Test connection to a build host.
		// Report connection issues to client
	},
	
	constructor: function (appPOM) {
		
	},
	
	prototype: {
		
	}
	
});

