com.scottbyrns.BuildSystem.DependenciesMap({
	
	setup: function () {

	},
	
	constructor: function (appPOM) {
		
	},
	
	prototype: {
		
	}
	
});