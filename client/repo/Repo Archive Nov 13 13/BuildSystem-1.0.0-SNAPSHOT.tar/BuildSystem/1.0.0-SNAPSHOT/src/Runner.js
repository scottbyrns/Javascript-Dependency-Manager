// runner of jobs who build targets

com.scottbyrns.BuildSystem.Runner({
	setup: function () {
		
	},
	constructor: function (job) {
		this.job = job;
	},
	prototype: {
		run: function () {
			
		}
	}
})