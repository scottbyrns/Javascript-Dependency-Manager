// A target is where the builds output will go.
com.scottbyrns.BuildSystem.Target({
	setup: function () {
		
	},
	constructor: function (success, failure, output) {
		
	},
	prototype: {
		run: function () {
			
		}
	}
})