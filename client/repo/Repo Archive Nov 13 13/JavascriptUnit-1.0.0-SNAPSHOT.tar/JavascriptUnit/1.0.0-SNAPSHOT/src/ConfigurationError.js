com.scottbyrns.JavascriptUnit.ConfigurationError({
	setup: function () {},
	constructor: function () {
	    this.message = "The configuration you provided was incomplete or invalid.";
	},
	prototype: {}
});